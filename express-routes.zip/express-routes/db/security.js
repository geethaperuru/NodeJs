const users = [
    {
        uname : 'admin',
        pass : 'admin@123'
    },
    {
        uname : 'tech',
        pass : 'tech'
    }
]

module.exports.users = users;