let projects = [
    {
        id: 1,
        name : 'AT & T',
        description : 'ATT is one of the largest telecom & satellite network providers'
    },
    {
        id: 2,
        name : 'Google',
        description : 'The biggest Search Engine'
    },
    {
        id: 3,
        name : 'Facebook',
        description : 'Best place to waste your time'
    }
]

module.exports.projects = projects;