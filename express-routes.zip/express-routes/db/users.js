let users = [
    {
        id: 1,
        name : 'John',
        email : 'joe@email.om',
        ass:0
    },
    {
        id: 2,
        name : 'Bob',
        email : 'bob@email.om',
        ass:0
    },
    {
        id: 3,
        name : 'Adam',
        email : 'adam@email.om',
        ass:0
    }
]

module.exports.users = users;