const teams = require('../db/teams').teams;
class teamService{
    //users=[];
    constructor(){
        this.teams = teams;
    }
    _all(){
        return this.teams;
    }
    _add(team){
        this.teams.push(team);
        return this.team;
    }
}

module.exports.teamService = teamService;